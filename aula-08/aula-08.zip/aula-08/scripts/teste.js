const arrow = () => {
    console.log('Arrow')
}


export default arrow