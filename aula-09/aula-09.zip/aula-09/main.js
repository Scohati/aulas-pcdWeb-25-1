import { retornaInformacoesCarro, carro } from "./scripts/carro.js";
import { buscaListaPokemons, url } from "./scripts/pokemon.js";

retornaInformacoesCarro()
buscaListaPokemons()


console.log(carro)